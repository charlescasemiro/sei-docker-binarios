<?php

/**
 * @generate-function-entries
 * @generate-legacy-arginfo
 */

function uploadprogress_get_info(string $identifier): ?array {};

function uploadprogress_get_contents(string $identifier, string $fieldname, int $maxlen=-1): ?string {};

